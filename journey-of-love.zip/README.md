# Simple 2D Game

This is a simple 2D game where a character navigates through hurdles to reach the end of the stage.

## How to Run
1. Make sure you have Python and Pygame installed.
2. Run the `main.py` file to start the game.

## Game Features
- Character movement
- Hurdles to avoid
- Simple stage structure
